import $ from 'jquery';

$.ajaxSetup({
    headers:{
        'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content'),
    }
})




$('.content').on('click','.outer-nav > span',function (){
    $(event.target).toggleClass('closed');
    if($(event.target).hasClass('closed')){
        $('nav').animate({
            width:'0px',
        });
        $('.page-content').animate({
            width:'100%'
        })
    }else{
        $('nav').animate({
            width:'200px',
        });
        $('.page-content').animate({
            width:window.innerWidth - 200
        })
    }
})


$('.content').on('click','nav .list_data p',function (){
    $(this).next().slideToggle();
})

<template>
    <div>
        <navbar-component></navbar-component>
        <div class="page-content info-data-style">

            <div class="container">
                <h2 class="main-title" style="font-size: 20px">
                    <span>مرحبا بك في صفحه البيانات</span>
                    <span  v-if="status == 1">المنتهيه</span>
                    <span  v-else>غير المنتهيه</span>
                </h2>
                <div class="header-controls d-flex justify-content-between titles">
                    <p class="text-center">
                        <span>الذهاب لصفحه البيانات</span>
                        <inertia-link  href="?status=1"> منتهية</inertia-link>
                        <span>/</span>
                        <inertia-link  href="?status=0"> غير منتهية</inertia-link>
                    </p>
                    <div>
                        <p class="text-left d-inline-block">
                            <button v-if="$page.props.user_personal_data.type == 'admin' || $page.props.user_personal_data.control == 1" class="btn btn-primary" @click="updateItem(null,0)" data-toggle="modal" data-target="#saveItem">اضافه بيان جديد</button>
                        </p>
                        <p class="text-left d-inline-block">
                            <button v-if="$page.props.user_personal_data.type == 'admin' || $page.props.user_personal_data.control == 1" class="btn btn-warning"  data-toggle="modal" data-target="#print_columns">طباعه</button>
                        </p>
                        <p class="text-left d-inline-block">
                            <button  class="btn btn-dark" @click="refresh">تحديث البيانات</button>
                        </p>
                    </div>
                </div>

                <p class="alert alert-info text-right mt-2">
                    اذا ارد تظليل صف قم بالضغط علي اي خليه لتظليل الصف بلون معين ان اردت الغاء التظليل قم بالضغط عليه مره لاخري لالغاء التظليل
                </p>
                <div class="overflow-auto">
                    <table class="myTable table table-bordered  table-hover text-center table-striped"
                           data-order='[[ 0, "desc" ]]'
                    >
                    <thead>
                        <tr>
                        <td>الرقم التسلسلي</td>
                        <td>اسم المستخدم</td>
                        <td>اسم الشركه</td>
                        <td>الصنف</td>
                        <td>المنشأ</td>
                        <td>المصدر</td>
                        <td>رقم الفاتورة</td>
                        <td>قيمة الفاتورة</td>
                        <td>ACID</td>
                        <td>اذن الاستيراد</td>
                        <td>رقم الحاوية</td>
                        <td>الوجهة</td>
                        <td>الخط</td>
                        <td>بوليصة</td>
                        <td>المركب</td>
                        <td>وصول</td>
                        <td>التعليمات</td>
                        <td>سماح</td>
                        <td>رفع</td>
                        <td>46</td>
                        <td>الطلب</td>
                        <td>الكشف</td>
                        <td>وزن</td>
                        <td>عدد</td>
                        <td>ملاحظات عامة</td>
                        <td>تاريخ الصرف</td>
                        <td>مطابقه</td>
                        <td>منتهي</td>
                        <td v-if="$page.props.user_personal_data.type == 'admin'">التحكم</td>
                        <td v-else-if="$page.props.user_personal_data.control == 1">التحكم</td>
                    </tr>
                    </thead>

                    <tbody>
                    <tr v-for="(item,index) in output" :key="index" :id="'row_'+index">
                        <td :id="'id_'+item['id']" style="font-weight: bold">{{ item.id }}</td>
                        <td :id="'user_'+item['id']" style="color:green; font-weight:bold;">{{ item.user.name }}</td>
                        <td :id="'company_'+item['id']" style="color:blue; font-weight:bold;">{{ item.company.name }}</td>
                        <td :id="'item_'+item['id']" style="color:coral; font-weight: bold">{{ item.item }}</td>
                        <td :id="'country_'+item['id']" style="color:cornflowerblue; font-weight: bold">{{ item.country.name }}</td>
                        <td :id="'exporter_'+item['id']" style="color:darkmagenta;font-weight:bold;">{{ item.exporter.name }}</td>
                        <td :id="'bill_number_'+item['id']" style="color:darkred; font-weight:bold;">{{ item.bill_number }}</td>
                        <td :id="'bill_value_'+item['id']" style="color:darkgreen;font-weight:bold;">{{ item.bill_value }}</td>
                        <td :id="'ACID_'+item['id']" style="font-weight: bold">{{ item.ACID }}</td>
                        <td :id="'permission_'+item['id']" style="color:hotpink;font-weight:bold;">{{ item.permission }}</td>
                        <td :id="'number_container_'+item['id']" style="color:cornflowerblue; font-weight: bold">{{ item.number_container }}</td>
                        <td :id="'destination_'+item['id']" style="color:purple; font-weight: bold">{{ item.destination.name }}</td>
                        <td :id="'line_'+item['id']" style="color:coral; font-weight: bold">{{ item.line }}</td>
                        <td :id="'policy_'+item['id']" style="color:green; font-weight:bold;">{{ item.policy }}</td>
                        <td :id="'vehicle_'+item['id']" style="color:darkred; font-weight:bold;">{{ item.vehicle }}</td>
                        <td :id="'arrived_'+item['id']" style="color:cornflowerblue; font-weight: bold">{{ item.arrived }}</td>
                        <td :id="'instructions_status_'+item['id']" style="font-weight: bold">{{ item.instructions_status }}</td>
                        <td :id="'allowed_'+item['id']" style="color:darkgreen;font-weight:bold;">{{ item.allowed }}</td>
                        <td :id="'lifting_status_'+item['id']" style="color:darkblue; font-weight: bold">{{ item.lifting_status }}</td>
                        <td :id="'forty_six_number_'+item['id']" style="color:#086868; font-weight: bold">{{ item.forty_six_number }}</td>
                        <td :id="'request_number_'+item['id']" style="color:darkred; font-weight:bold;">{{ item.request_number }}</td>
                        <td :id="'statement_status_'+item['id']">{{ item.statement_status }}</td>
                        <td :id="'weight_'+item['id']" style="color:cornflowerblue; font-weight: bold">{{ item.weight }}</td>
                        <td :id="'number_data_'+item['id']" style="color:goldenrod; font-weight: bold">{{ item.number_data }}</td>
                        <td :id="'notes_'+item['id']" style="color:purple; font-weight: bold">{{ item.notes }}</td>
                        <td :id="'exchange_date_'+item['id']" style="color:coral; font-weight: bold">{{ item.exchange_date }}</td>
                        <td :id="'matching_status_'+item['id']" style="color:darkgreen;font-weight:bold;">{{ item.matching_status }}</td>
                        <td :id="'status_'+item['id']" style="color:cornflowerblue; font-weight: bold">{{ item.status == 1 ?'منتهي':'غير منتهي' }}</td>
                        <td class="control" v-if="$page.props.user_personal_data.type == 'admin' || $page.props.user_personal_data.control == 1">
                            <span><i @click="updateItem(item,index)" data-toggle="modal" data-target="#saveItem" class="ri-edit-2-line"></i></span>
                            <span><i @click="deleteItem(item.id,'info_datas')" class="ri-delete-bin-line"></i></span>
                        </td>
                    </tr>
                    </tbody>
                </table>
                </div>
            </div>


            <!-- Modal -->
            <div class="modal fade" id="print_columns" tabindex="-1" role="dialog" aria-labelledby="saveItem" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="print_columns_model">
                                طباعه البيانات
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form @submit.prevent="select_columns_before_print">
                                <div class="form-group privillages">
                                    <h4 class="mb-2">اسماء الاعمدة</h4>
                                    <button type="button" class="btn btn-primary selectAll" @click="selectAll">تحديد االكل</button>
                                    <div class="mt-2 d-flex flex-wrap">
                                        <div class="input-check mb-2 ml-4" v-for="(column,index) in columns" :key="index">
                                            <input type="checkbox" name="columns[]" :value="index">
                                            <span>{{ column }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" value="حفظ" >
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Modal -->
            <div class="modal fade" id="saveItem" tabindex="-1" role="dialog" aria-labelledby="saveItem" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">
                                {{ item == null ? 'اضافه بيان جديد'
                                :
                                'تعديل بيانات '
                                +
                                item.item
                                }}
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form name="role_data" class="form_icons" method="post" @submit.prevent="save_user" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label>اسم الشركة</label>
                                    <select v-if="$page.props.user_personal_data.type == 'admin'" name="company_id" class="form-control" required>
                                        <option value="">اختر فرع الشركة</option>
                                        <option v-for="(c,index) in companies" :key="index" :value="c.id" :selected="item != null &&  c.id == item.company_id">{{ c.name }}</option>
                                    </select>

                                    <select v-else name="company_id" class="form-control" required>
                                        <option value="">اختر فرع الشركة</option>
                                        <option v-for="c in companies" :key="c" :value="c.company_id" :selected="item != null &&  c.company.id == item.company_id">{{ c.company.name }}</option>
                                    </select>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>الصنف</label>
                                    <input name="item"
                                           class="form-control" :value="item != null  ? item.item:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>المنشا</label>
                                    <select  name="country_id" class="form-control" required>
                                        <option value="">اختر المنشأ </option>
                                        <option v-for="e in countries" :key="e.id" :value="e.id"
                                                :selected="item != null &&  e.id == item.country_id">{{ e.name }}</option>
                                    </select>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>المصدر</label>
                                    <select  name="exporter_id" class="form-control" required>
                                        <option value="">اختر المصدر</option>
                                        <option v-for="(e,index) in exporters" :key="index" :value="e.id" :selected="item != null &&  e.id == item.exporter_id">{{ e.name }}</option>
                                    </select>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>رقم الفاتورة</label>
                                    <input name="bill_number"
                                           class="form-control" :value="item != null  ? item.bill_number:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>قيمه الفاتورة</label>
                                    <input name="bill_value"
                                           class="form-control" :value="item != null  ? item.bill_value:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>ACID</label>
                                    <input name="ACID" @blur="checknumbersize"
                                           class="form-control" type="number" :value="item != null  ? item.ACID:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>اذن الاستيراد</label>
                                    <input name="permission"
                                           class="form-control"  :value="item != null  ? item.permission:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>رقم الحاوية</label>
                                    <input name="number_container"
                                           class="form-control" :value="item != null  ? item.number_container:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>الواجهة</label>
                                    <select name="destination_id" v-if="$page.props.user_personal_data.type == 'admin'"
                                           class="form-control"
                                            required>
                                        <option value="">اختر الوجهه</option>
                                        <option v-for="i in destinations"
                                                :selected="item != null  && item.destination_id == i['id']"
                                                :value="i['id']">
                                            {{ i['name'] }}
                                        </option>
                                    </select>
                                    <select v-else class="form-control" name="destination_id" required>
                                        <option value="">اختر الوجهه</option>
                                        <option v-for="i in user_destinations"
                                                :selected="item != null  && item.destination_id == i['destination']['id']"
                                                :value="i['destination']['id']">
                                            {{ i['destination']['name'] }}
                                        </option>
                                    </select>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>الخط</label>
                                    <input name="line"
                                           class="form-control" :value="item != null  ? item.line:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>بوليصة</label>
                                    <input name="policy"
                                           class="form-control"  :value="item != null  ? item.policy:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>المركب</label>
                                    <input name="vehicle"
                                           class="form-control" :value="item != null  ? item.vehicle:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>وصول</label>
                                    <input name="arrived"
                                           class="form-control" type="date" :value="item != null  ? item.arrived:''"
                                           required>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>التعليمات</label>
                                    <select name="instructions_status"
                                           class="form-control"
                                           :value="item != null  ? item.instructions_status:''"
                                            required>
                                        <option value="">اختر الحالة المناسبة</option>
                                        <option value="تعليمات"
                                                :selected="item != null &&  item.instructions_status == 'تعليمات'">تعليمات</option>
                                        <option value="اصل" :selected="item != null &&  item.instructions_status == 'اصل'">اصل</option>
                                        <option value="مستلم" :selected="item != null &&  item.instructions_status == 'مستلم'">مستلم</option>
                                    </select>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>سماح</label>
                                    <input name="allowed"
                                           class="form-control" :value="item != null  ? item.allowed:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>رفع</label>
                                    <select name="lifting_status"
                                            class="form-control"
                                            :value="item != null  ? item.lifting_status:''"
                                            required>
                                        <option value="">اختر الحالة المناسبة</option>
                                        <option value="نعم"
                                                :selected="item != null &&  item.lifting_status == 'نعم'">نعم</option>
                                        <option value="لا" :selected="item != null &&  item.lifting_status == 'لا'">لا</option>

                                    </select>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>46</label>
                                    <input name="forty_six_number"
                                           class="form-control" type="number" :value="item != null  ? item.forty_six_number:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>الطلب</label>
                                    <input name="request_number"
                                           class="form-control" type="number" :value="item != null  ? item.request_number:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>الكشف</label>
                                    <select name="statement_status"
                                            class="form-control"
                                            :value="item != null  ? item.statement_status:''"
                                            required>
                                        <option value="">اختر الحالة المناسبة</option>
                                        <option value="تم الكشف"
                                                :selected="item != null && item.statement_status == 'تم الكشف'">تم الكشف</option>
                                        <option value="الكشف اليوم"
                                                :selected="item != null &&  item.statement_status == 'الكشف اليوم'"
                                        >الكشف اليوم</option>

                                        <option value="جاهزة"
                                                :selected="item != null && item.statement_status == 'جاهزة'"
                                        >جاهزة</option>

                                        <option value="غير مستعدة"
                                                :selected="item != null && item.statement_status == 'غير مستعدة'"
                                        >غير مستعدة</option>

                                    </select>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>الوزن</label>
                                    <input name="weight"
                                           class="form-control" type="number" :value="item != null  ? item.weight:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>العدد</label>
                                    <input name="number_data"
                                           class="form-control" type="number" :value="item != null  ? item.number_data:''"
                                           required>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>ملاحظات عامه</label>
                                    <textarea name="notes"
                                           class="form-control"  :value="item != null  ? item.notes:''">{{ item != null ? item.notes : ''}}</textarea>
                                    <span><i class="ri-information-line"></i></span>
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>تاريخ الصرف</label>
                                    <input name="exchange_date"
                                           :value="exchange_date_val"
                                           @keyup="updateExchangeDate"
                                           class="form-control"
                                           >
                                    <p class="alert alert-danger"></p>
                                </div>
                                <div class="form-group">
                                    <label>منتهي</label>
                                    <select name="status" class="form-control" >
                                        <option value="">اختر الحالة المناسبة</option>
                                        <option value="1" :selected="item != null && item.status == 1">منتهي</option>
                                        <option value="0" :selected="item != null && item.status == 0">غير منتهي</option>
                                    </select>

                                    <p class="alert alert-danger"></p>
                                </div>

                                <div class="form-group">
                                    <label>مطابقه</label>
                                    <select name="matching_status"
                                            class="form-control"
                                            :value="item != null  ? item.matching_status:''"
                                            required>
                                        <option value="">اختر الحالة المناسبة</option>
                                        <option value="نعم"
                                                :selected="item != null &&  item.matching_status == 'نعم'">نعم</option>

                                        <option value="لا"
                                                :selected="item != null &&  item.matching_status == 'لا'">لا</option>

                                    </select>
                                    <p class="alert alert-danger"></p>
                                </div>

                                <div class="form-group">
                                    <input type="submit" class="btn btn-success" value="حفظ">
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</template>

<script>
import NavbarComponent from "../components/navbar-component";
import deleteItem from "../mixin/deleteItem";
import errorAjax from "../mixin/errorAjax";

export default {
    name: "info_data",
    mixins:[deleteItem,errorAjax],
    components: {NavbarComponent},
    props:['data','companies','user_destinations','destinations','countries','exporters'],
    data:function (){
        return{
            item:null,
            output:this.data,
            status:0,
            exchange_date_val:'',
            current_index:0,
            tableObj:null,
            columns:[
                'الرقم التسلسلي',
                'اسم المستخدم',
                'اسم الشركه',
                'الصنف',
                'المنشأ',
                'المصدر',
                'رقم الفاتورة',
                'قيمة الفاتورة',
                'ACID',
                'اذن الاستيراد',
                'رقم الحاوية',
                'الوجهة',
                'الخط',
                'بوليصة',
                'المركب',
                'وصول',
                'التعليمات',
                'سماح',
                'رفع',
                '46',
                'الطلب',
                'الكشف',
                'وزن',
                'عدد',
                'ملاحظات عامة',
                'تاريخ الصرف',
                'مطابقه',
                'منتهي',
            ],
        }
    },
    computed:{

    },
    mounted() {
        $('.myTable thead tr td').each(function () {
            var title = $(this).text();
            if(title == 'مطابقه' || title == 'منتهي' || title == 'التحكم' || title == 'عدد'
                || title == 'وزن' ||  title == 'رفع' || title ==  'التعليمات' || title == 'سماح' || title == 'الطلب' || title == 'الوجهة'){
                $(this).html('<input style="width:90px;"  class="form-control" type="text" placeholder="' + title + '" />');
            }else{
                $(this).html('<input style="width:150px;"  class="form-control" type="text" placeholder="' + title + '" />');
            }
        });

        $.noConflict(true);
        var table = $('.myTable').DataTable();

        // Apply the search
        table.columns().every( function () {
            var that = this;

            $( 'input', this.header() ).on( 'keyup change', function () {
                that
                    .search( this.value )
                    .draw();
            } );
        } );
        this.tableObj = table;
        setTimeout(()=>{
            global.jQuery = require('jquery');
            var $ = global.jQuery;
            window.$ = $;
        },1500)


        // add event click on every td
        $('table tr td:not(:last-of-type)').on('click',function(){
            $(this).parent().toggleClass('color_tr');
        })
    },
    created() {
        if(document.URL.split('?status=')[1] != undefined){
            if(parseFloat(document.URL.split('?status=')[1]) == 1){
                this.status = 1;
            }else{
                this.status = 0;
            }
        }else{
            this.$inertia.visit('?status=0');
            // منتهيه
            var status = 1;
        }


    },
    methods:{
        updateItem:function (item,current_index){
            console.log(item);
            console.log(current_index);
            this.item = item;
            if(this.item != null) {
                this.exchange_date_val = this.item.exchange_date;
            }
            this.current_index = current_index;
        },
        checknumbersize:function (){
           if(event.target.value.length != 19){
               Toast.fire({
                    icon:'error',
                    title:'لابد ان يكون ال ACID مكون من 19 رقم',
               });
               $(event.target).parent().parent().find('input[type="submit"]').attr('disabled','disabled');
           }else{
               $(event.target).parent().parent().find('input[type="submit"]').removeAttr('disabled');
           }
        },
        updateExchangeDate:function (){
           /* console.log(event.target.value);
          this.exchange_date_val = event.target.value;*/
        },
        save_user:function (){
            var com = this;
            var target = $(event.target);
            var form_data = new FormData(event.target);
            if(this.item != null){
                form_data.append('id',this.item.id);
            }
            if(document.URL.split('?status=')[1] != undefined){
                var status = document.URL.split('?status=')[1];
            }else{
                // منتهيه
                var status = 1;
            }
            form_data.append('status_url',status);

            $.ajax({
                headers:{
                  'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content'),
                },
                url:'/infodata/save',
                type:'POST',
                data:form_data,
                processData: false,
                contentType: false,
                beforeSend: function(){
                    Toast.fire({
                        icon: 'info',
                        title: 'من فضلك انتظر حتي يتم اكتمال التحميل'
                    });
                },
                success:function (data){
                    this.handleErrorAjax(data,target);
                    if(data.hasOwnProperty('success')){

                        // close modal
                        $('.modal form')[0].reset();
                        $('.modal').modal('hide');


                       /* $.noConflict(true);
                        let table = $('.myTable').DataTable();*/
                        console.log($);
                        var table = com.tableObj;
                    /*    new_data.push(current_row_column_values[current_row_column_values.length-1]);
                        console.log(data['success'])
                        console.log(new_data);
                        table.row('#row_'+this.current_index).data(new_data).draw();*/


                        // check if status is update
                        if(data['id_status'] != null) {



                            var index = this.output.indexOf(this.output.find((e)=>{
                                return e['id'] == data['id_status']
                            }));
                            this.output[index] = data['success']


                            for(let property in data['success']){
                                if(typeof data['success'][property] !='object' &&
                                    property.indexOf('created_at') == -1 &&  property.indexOf('updated_at') == -1){
                                    if(property.indexOf('id') == -1) {
                                        if(property == 'status'){
                                            if(data['success'][property] == 1){
                                                table.cell('#'+property+'_'+this.item['id']).data('غير منتهي').draw()
                                            }else{
                                                table.cell('#'+property+'_'+this.item['id']).data('منتهي').draw()
                                            }
                                        }else {
                                            table.cell('#'+property+'_'+this.item['id'])
                                                .data(data['success'][property]).draw()
                                        }
                                    }else{
                                        if(property == 'id'){

                                        }else {
                                            var new_prop = property.replace('_id', '');
                                            table.cell('#'+new_prop+'_'+this.current_index)
                                                .data(this.item['id']).draw()
                                        }
                                    }
                                }
                                //    console.log(data['success'][property]);
                            }


                            // = data['success'];
                        }else{
                           // this.output.push(data['success']);
                        }
                        Toast.fire({
                            icon: 'success',
                            title: 'تم حفظ البيان بنجاح'
                        });
                        this.current_index = 0;
                        this.item = null;
                        /*setTimeout((e)=>{
                            com.$inertia.visit(document.URL);
                           // window.location = document.URL
                        },1500);*/
                    }
                }.bind(this)
            });

        },
        selectAll:function(){
            $(event.target).next().find('input').toggleClass('checked');
            for(var input of $(event.target).next().find('input')){
                if($(input).hasClass('checked')){
                    $(input).prop('checked',true);
                }else{
                    $(input).prop('checked',false);
                }
            }
        },
        select_columns_before_print(){
           // $('form input[type="checkbox"]:checked');
            var mywindow = window.open('', 'PRINT');

            mywindow.document.write('<html><head<title>Elsawfa 2009</title>');
            mywindow.document.write('</head><body style="direction: rtl; padding: 25px;"><h1 style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px"><span>تقرير عن احصائيات البيانات</span><span>التاريخ : '+new Date().toLocaleString()+'</span></h1><table style="width: 100%; max-width: 100%; border-collapse:collapse margin-bottom: 1rem;"><thead><tr>');
            for(let input of $('form input[type="checkbox"]:checked')){

                mywindow.document.write('<td style="text-align: center; font-weight: bold;">'+$('table thead tr td:not(:last-of-type)').eq(input.value).html()+'</td>');
            }

            mywindow.document.write('</tr></thead><tbody>');


            for(let tr of $('table tbody tr')){
                mywindow.document.write('<tr>');
                for(let input of $('form input[type="checkbox"]:checked')){
                    mywindow.document.write('<td style="padding: 0.75rem; vertical-align: top; text-align: center; border-top: 1px solid #dee2e6;">'+$(tr).find('td').eq(input.value).html()+'</td>');
                }
                mywindow.document.write('</tr>');

            }

            mywindow.document.write('</tbody>');

            mywindow.document.write('</table></body></html>');

            mywindow.document.close(); // necessary for IE >= 10
            mywindow.focus(); // necessary for IE >= 10*/

            mywindow.print();
            mywindow.close();
        },
        print_paper:function(){

        },
        refresh:function(){
            window.location = document.URL
        }
    }
}
</script>

<style lang="scss" scoped>
.modal.show .modal-dialog{
    max-width: 55%;
}
.page-content{
    padding-top: 0px;
}
table{
    tbody{
        tr{
            td{
                font-size: 18px;
            }
        }
    }
}
.container{
    width:100%;
    max-width: 100%;
}
.color_show{
    width: 80px;
    height: 30px;
    display: block;
    margin: auto;
    border-radius: 6px;
}
h2{
    &::before{
        display: none;
    }
    &::after{
        display: none;
    }
}
.titles{

    a{
        font-size: 20px;
    }
}
.header-controls{
    p{
        margin-bottom: 0px;
    }
}
.color_tr{
    background-color: #bbbbbb !important;
}
@media print {


}
</style>

<template>

</template>

<script>
export default {
    name: "updateCurrentItem",
    methods:{
        updateItem:function (item){
            this.item = item;
        },
    }
}
</script>

<style scoped>

</style>
